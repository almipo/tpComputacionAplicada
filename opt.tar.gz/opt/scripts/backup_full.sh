
#!/bin/bash

#-help 

if [[ "$1" == "-help" ]]; then
echo 
echo 
echo "Uso: $0 <origen> [destino]"
echo
echo "si no especifica destino se usara /backup_dir"
echo
echo "Ejemplo:"
echo " $0 /var/log /backup_dir"
echo 
echo "genera un archivo de backup comprimido con la fecha en formato YYYYMMDD"
echo "Ejemplo de salida: log_bkp_20251104.tar4.gz"
exit 0
fi

#validar datos 
if [[ $# -lt 1 || $# -gt 2 ]]; then 
echo "ERROR: no se especifico origen "
echo "Use '$0 -help' para ver el modo de uso"
echo
echo
exit 1
fi

#verificar que origen y destino existe

origen="$1"
destino="${2:-/backup_dir}"
fecha=$(date +"%Y%m%d")

if [[ ! -d "$origen" ]]; then
echo "ERROR: El directorio de origen $origen no existe."
exit 2
fi

if [[ ! -d "$destino" ]]; then
echo "ERROR: El directorio de destino $destino no existe."
exit 3
fi
 
if ! mountpoint -q "$destino" && ! df "$destino" &>/dev/null; then
echo "Error: El destino $destino no esta disponible o montado"
exit 4
fi

#crea nombre de archivo segun el orifgen

nombre=$(basename "$origen")
archivo="${nombre}_bkp_${fecha}.tar.gz"

echo "Generando backup de $origen "
tar -czf "$destino/$archivo" -C "$(dirname "$origen")" "$(basename "$origen")"

if [[ $? -eq 0  ]]; then
echo "BACKUP COMPLETADO: $destino/$archivo"
else
echo "ERROR: al generar el backup"
exit 5
fi




 




